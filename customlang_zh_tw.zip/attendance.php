<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from http://localhost/moodle
 *
 * @package    mod
 * @subpackage attendance
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['addmultiplesessions'] = '新增每周點名時間';
$string['addsession'] = '新增點名時段';
$string['allowupdatestatus'] = '允許學生更新自己的點名記錄';
$string['allowupdatestatus_desc'] = '當選取時，學生可在自行點完名，且尚未結束點名時間時更改自己的出席狀況';
$string['allowupdatestatus_help'] = '如果選中，學生只能在點名期間進行點名，超過點名時間就算還於上課時間內也不允以點名';
$string['allpast'] = '已結束的';
$string['attendance_no_status'] = '已經超過點名時間';
$string['attendance:addinstance'] = '新增一項點名活動';
$string['attendance:changeattendances'] = '更改點名情況';
$string['attendance:import'] = '匯入報(csv)';
$string['attendance:takeattendances'] = '記錄點名情形';
$string['attendance:view'] = '檢視出席情況';
$string['attendancegrade'] = '點名成績';
$string['attendancenotstarted'] = '此一課程還未開始點名';
$string['attendancepercent'] = '出缺席比例';
$string['attendanceslogged'] = '點名紀錄';
$string['attendancestaken'] = '成功簽到';
$string['attendanceupdated'] = '點名狀況已更新';
$string['autoassignstatus'] = '學生無須手動設定狀態';
$string['autoassignstatus_help'] = '如果選擇此項學生在進行簽到的時候會自動分配一個狀態';
$string['automarkall'] = '出席就標記';
$string['automarkclose'] = '活動結束時標記';
$string['automarkingcomplete'] = '自動標記完成';
$string['automarkingnotavailableyet'] = '目前會話未結束，會話結束時自動標記';
$string['automarkuseempty'] = '自動標記狀態"未標記"處理';
$string['automarkuseempty_desc'] = '當勾選了相應的設置時，系統在進行自動標記考勤的過程中，將允許那些具有空或"未標記"的狀態項被標記。也就是說，這種設置允許自動標記過程中考慮那些沒有指定條件的狀態。';
$string['calendarevent'] = '為點名時段建立行事曆';
$string['calendarevent_help'] = '如果啟用，將為點名時段建立行事曆。 
如果禁用，此點名時段的任何現有行事曆事件都將被刪除。';
$string['caleventcreated'] = '已成功建立行事曆事件';
$string['caleventdeleted'] = '已順利刪除行事曆事件';
$string['changeduration'] = '更改點名中止時間';
$string['changesession'] = '更改點名時間';
$string['checkweekdays'] = '選擇會話日期範圍內的工作日';
$string['commonsession'] = '所有學生';
$string['commonsessions'] = '所有學生';
$string['countofselected'] = '所選項目的數量';
$string['createmultiplesessions'] = '建立多個點名時間';
$string['createmultiplesessions_help'] = '這個功能讓您可以一次輕鬆創建多個點名時間。上述的點名日期開始，並持續到結束日期。 * <strong>重複於</strong>：選擇您的課程將在哪些星期幾上課（例如，星期一/星期三/星期五）。 * <strong>每隔</strong>：這是一個頻率設置。如果您的課程每週點名一次，請選擇1；如果每兩週點名一次，請選擇2；每三週一次，請選擇3，依此類推。 * <strong>結束於</strong>：選擇課程的最後一天（您希望進行點名的最後一天）。';
$string['customexportfields'] = '自訂匯出使用者資料欄位';
$string['customexportfields_help'] = '在匯出報告中額外自訂使用者資料欄位';
$string['defaultsessionsettings'] = '創建點名活動預設值';
$string['defaultsessionsettings_help'] = '這些設置為新建立的點名活動設定默認值';
$string['defaultsettings'] = '默認點名設置';
$string['defaultsettings_help'] = '這些設置為新的點名活動設定默認值。';
$string['defaultsubnet'] = '預設網路地址';
$string['defaultsubnet_help'] = '創建一個以逗號分割的IP列表，表示只能在這些子網中進行點名';
$string['defaultview'] = '檢視畫面';
$string['defaultview_desc'] = '這表示在打開點名紀錄時預設的排序';
$string['defaultwarningsettings'] = '警告設定';
$string['defaultwarningsettings_help'] = '這些設置為警告定義默認值';
$string['deletedgroup'] = '有關此時段的點名活動已經被刪除';
$string['deletehiddensessions'] = '刪除所有隱藏的點名時段';
$string['deletesession'] = '刪除點名時段';
$string['deletesessions'] = '刪除所有點名時段';
$string['deletingsession'] = '刪除此課程的點名時段';
$string['deletingstatus'] = '刪除點名的狀態';
$string['emailsubject_help'] = '當要發送時，郵件主旨';
$string['emailuser'] = '電子郵件用戶';
$string['emailuser_help'] = '如果選取，將會向學生發送警告';
$string['enablewarnings'] = '警告';
$string['enablewarnings_desc'] = '這允許為活動設定一個警告集，當點名低於配置的閾值時，會向用戶發送電子郵件通知
警告：這是一個新功能，並且並未進行大規模的測試。請謹慎使用，如果您發現它運作良好，請在 Moodle 論壇提供反饋。"';
$string['includeqrcode'] = '掃描QRcode';
$string['maxwarn'] = '郵件的最大警告次數';
$string['maxwarn_help'] = '同樣一個點名活動對同樣一個電子郵件，最多發送警告的次數。
如超過此次數將不再對該郵件發送警告';
$string['mobilesessionfrom'] = '顯示更早的點名活動';
$string['mobilesessionfrom_help'] = '允許在應用程式中進行標記時限制活動 - 只顯示從此值開始的點名活動';
$string['mobilesessionto'] = '顯示未來的活動';
$string['mobilesessionto_help'] = '允許限制點名活動列表，僅顯示未來的點名活動';
$string['mobilesettings'] = '行動應用程式設定';
$string['mobilesettings_help'] = '這些設定控制 Moodle 行動應用程式的行為';
$string['multisessionexpanded'] = '展開多個點名設置';
$string['multisessionexpanded_desc'] = '在創建新的點名活動時，將展開所有設置。使教師能夠方便地查看和調整這些設置。';
$string['passwordgrp'] = '通關密碼';
$string['passwordgrp_help'] = '如果設置了密碼，學生在進行簽到的時候需要輸入這個密碼。如果未設置，則不需要密碼。';
$string['preventsharedip_help'] = '防止學生用相同的IP進行點名';
$string['preventsharediptime'] = '允許 IP 地址重新使用的時間（分鐘）';
$string['preventsharediptime_help'] = '在此時間結束後，允許相同的 IP 地址在此點名活動中重新用於進行點名';
$string['randompassword'] = '隨機通關密碼';
$string['repeatasfollows'] = '重複下方所選時段';
$string['rotateqrcode'] = '自動更新QR 碼';
$string['rotateqrcodeexpirymargin'] = 'QR碼/密碼的過期時間';
$string['rotateqrcodeexpirymargin_desc'] = '秒過期之前產生過的QR碼/密碼';
$string['rotateqrcodeinterval'] = '更新 QR 碼/密碼的間隔時間（秒）';
$string['rotateqrcodeinterval_desc'] = '秒更新一次QR 碼/密碼的間隔時間';
$string['showsessiondescriptiononreport'] = '在報告中顯示活動描述';
$string['showsessiondescriptiononreport_desc'] = '在報告清單中會顯示每個活動的描述';
$string['studentpassword'] = '通關密碼';
$string['studentscanmarksessiontime'] = '學生在課堂時間內點名';
$string['studentscanmarksessiontimeend'] = '預設點名結束時間';
$string['studentscanmarksessiontimeend_desc'] = '如果點名沒有設定結束時間，學生會有多少分鐘的時間可以記錄他們的出缺席';
$string['studentsearlyopentime'] = '提早點名';
$string['studentsearlyopentime_help'] = '可以讓你點名時間提早，這樣於上課開始就可直接上課';
$string['subnetactivitylevel'] = '允許在活動頁面進行子網配置';
$string['subnetactivitylevel_desc'] = '如果啟用，教師可以在創建點名活動時在活動層級覆蓋默認的子網。否則，在創建點名活動時將使用網站的預設值。';
$string['to'] = '~';
$string['warnafter'] = '前N次不發出警告';
$string['warnafter_help'] = '當用戶的點名記錄超過此數量時，才會觸發警告的條件';
$string['warningpercent'] = '如果百分比下降，則發出警告';
$string['warningpercent_help'] = '如果百分比低於此值將觸發警告';
